import React from 'react'

const LandlordsQues = () => {
  return (
    <div>LandlordsQues</div>
  )
}

export default LandlordsQues