import React from 'react'

const BuyersQues = () => {
  return (
    <div>BuyersQues</div>
  )
}

export default BuyersQues