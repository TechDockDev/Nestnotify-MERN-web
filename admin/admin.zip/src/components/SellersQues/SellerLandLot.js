import React from 'react'

const SellerLandLot = () => {
  return (
    <div>SellerLandLot</div>
  )
}

export default SellerLandLot