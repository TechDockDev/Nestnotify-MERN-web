import React from 'react'

const SellerResidentialCondo = () => {
  return (
    <div>SellerResidentialCondo</div>
  )
}

export default SellerResidentialCondo