import React from 'react'

const SellerCommercial = () => {
  return (
    <div>SellerCommercial</div>
  )
}

export default SellerCommercial