import React from 'react'

const RentersQues = () => {
  return (
    <div>RentersQues</div>
  )
}

export default RentersQues